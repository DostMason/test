#!/bin/bash
BOTNAME=$1
cat <<EOL > ./config/$BOTNAME.json
{
  "SteamLogin": "$BOTNAME",
  "RemoteCommunication": 0,
  "SteamMasterClanID": 0
}
EOL
echo "Bot $BOTNAME created"
