#!/bin/bash
CONFIG_DIR="./config"
for file in "$CONFIG_DIR"/*.json; do
  [[ "$file" == *"ASF.json" ]] && continue
  if grep -q '"RemoteCommunication"' "$file"; then
    sed -i 's/"RemoteCommunication":[ ]*[0-9]\+/"RemoteCommunication": 0/g' "$file"
  else
    sed -i '1s/{/{\n  "RemoteCommunication": 0,/' "$file"
  fi
done
echo "All bots updated: RemoteCommunication = 0"
